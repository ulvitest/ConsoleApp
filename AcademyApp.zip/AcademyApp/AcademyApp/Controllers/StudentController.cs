﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcademyApp.Controllers
{
    class StudentController
    {

       
    }
}
